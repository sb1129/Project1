# crx-download
Download CRX files as zip or directly.
